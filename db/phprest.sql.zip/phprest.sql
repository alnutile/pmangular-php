-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jul 02, 2013 at 03:27 PM
-- Server version: 5.5.31
-- PHP Version: 5.3.10-1ubuntu3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `phprest`
--

-- --------------------------------------------------------

--
-- Table structure for table `assigned`
--

CREATE TABLE IF NOT EXISTS `assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `people_id` int(11) DEFAULT NULL,
  `taskId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `assigned`
--

INSERT INTO `assigned` (`id`, `people_id`, `taskId`) VALUES
(1, 2, 100),
(2, 3, 100),
(3, 2, 99),
(4, 3, 98);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE IF NOT EXISTS `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'New system id',
  `drupalId` int(11) DEFAULT NULL COMMENT 'old drupal if needed id',
  `clientName` varchar(125) DEFAULT NULL COMMENT 'Client Name',
  `phone` varchar(35) DEFAULT NULL COMMENT 'Phone',
  `phone2` varchar(35) DEFAULT NULL COMMENT 'Phone',
  `notes` text COMMENT 'Notes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `drupalId`, `clientName`, `phone`, `phone2`, `notes`) VALUES
(1, 28, 'Client-1', '4445554444', '8888888888', 'This is a test existing client with tid 28'),
(3, 1, 'Client-3', '5555555', '53434343', 'asdfasdfa'),
(4, 6, 'Client-4', NULL, NULL, NULL),
(5, 24, 'Client-5', '5555555555', '4444444444', 'gadfgsdfg'),
(6, 14, 'Client-6', NULL, NULL, NULL),
(7, 2, 'Client-7', NULL, NULL, NULL),
(8, 23, 'Client-8', NULL, NULL, NULL),
(9, 44, 'Client-9', NULL, NULL, NULL),
(10, 35, 'Client-10', NULL, NULL, NULL),
(11, 3, 'Client-11', NULL, NULL, NULL),
(12, 17, 'Client-12', NULL, NULL, NULL),
(13, 46, 'Client-13', NULL, NULL, 'test chroma notes');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `comment` longtext,
  `created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `features`
--

CREATE TABLE IF NOT EXISTS `features` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drupalId` int(11) DEFAULT NULL,
  `name` varchar(55) DEFAULT NULL,
  `notes` longtext,
  `related_project` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=73 ;

--
-- Dumping data for table `features`
--

INSERT INTO `features` (`id`, `drupalId`, `name`, `notes`, `related_project`) VALUES
(37, 89, 'Bring forward the ability to display and interact with ', NULL, 0),
(38, 111, 'Bug', NULL, 0),
(39, 120, 'Bugs', NULL, 0),
(40, 81, 'Build Release Candidate', '', 0),
(41, 101, 'Content Entering', NULL, 0),
(42, 72, 'Create Computer-generated design compositions', 'Create initial (rough) computer generated design compositions of the top 2 ideas from the previous feature', 0),
(43, 75, 'Create Design Ideas', '', 0),
(44, 73, 'Create Detailed Composite', '', 0),
(45, 78, 'Create highly refined composite of selected concept', '', 0),
(46, 82, 'Create/prepare all files for delivery to production ser', '', 0),
(47, 129, 'Deployment', NULL, 0),
(48, 98, 'Employee Site', NULL, 0),
(49, 122, 'Home Page Rework', NULL, 0),
(50, 102, 'HTML', NULL, 0),
(51, 105, 'Internal Workflow', NULL, 0),
(52, 99, 'Maintenance Support', NULL, 0),
(53, 108, 'Test', NULL, 0),
(54, 71, 'Present a list of concept ideas for email campaign', 'Create a text-based list, or quick sketch renderings of brainstormed ideas for the email campaign, along with some ideas for copy, headlings, sub-heads, text, etc.', 0),
(55, 85, 'Provide quality assurance', '', 0),
(56, 125, 'QA Work', NULL, 0),
(57, 93, 'Quote Work', NULL, 0),
(58, 87, 'Send email release candidate to test group', '', 0),
(59, 95, 'Server Move', NULL, 0),
(60, 126, 'Staged Site Bugs', NULL, 0),
(61, 110, 'Tokens', NULL, 0),
(62, 128, 'Training', NULL, 0),
(63, 124, 'Version 5', NULL, 0),
(64, 92, 'Bug Support', '', 28),
(65, 76, 'Create Design Concepts', '', 0),
(66, 86, 'Proof read release candiate', '', 0),
(67, 79, 'Purchase and license all materials', 'Purchase and license all stock photography and font usage rights necessary for the project', 0),
(68, 83, 'Create emma campaign using FMK template', 'Using the FiberMark template created on Emma, create the new campaign email with previously generated artwork and files', 0),
(69, 74, 'Design Concepts', '', 0),
(70, 77, 'Design Development', '', 0),
(71, 80, 'Implementation', '', 0),
(72, 84, 'Production', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hostings`
--

CREATE TABLE IF NOT EXISTS `hostings` (
  `id` int(75) NOT NULL AUTO_INCREMENT,
  `clientId` int(11) NOT NULL,
  `levelId` varchar(256) NOT NULL,
  `notes` text NOT NULL,
  `backuplocation1` varchar(256) NOT NULL,
  `backuplocation2` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Storing hosting info' AUTO_INCREMENT=57 ;

--
-- Dumping data for table `hostings`
--

INSERT INTO `hostings` (`id`, `clientId`, `levelId`, `notes`, `backuplocation1`, `backuplocation2`) VALUES
(5, 1, '6', 'test', '/var/www/1', '/var/www/11'),
(6, 3, '2', 'test put', '/var/www/1', '/var/www/11'),
(7, 13, '1', '1914 translation by H. Rackham\n\n"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?"\n\nSection 1.10.33 of "de Finibus Bonorum et Malorum", written by Cicero in 45 BC\n\n"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat."\n\n', 'test1', 'Rackspace:imageNameExample'),
(8, 12, '1', 'This is a new hosting package for YMCA test 2', 'Server01:/var/www/example', 'Rackspace:imageNameExample'),
(9, 11, 'None Set', 'This is new', 'Server01:/var/www/example', 'Rackspace:imageNameExample'),
(10, 7, '1', 'sphhs test', 'Server01:/var/www/example', 'Rackspace:imageNameExample'),
(11, 1, '2', 'test 2 forms after git merge ', '/var/www/1', '/var/www/11'),
(12, 4, 'None Set', 'Any Notes?', 'Server01:/var/www/example', 'Rackspace:imageNameExample'),
(13, 6, 'None Set', 'Any Notes?', 'Server01:/var/www/example', 'Rackspace:imageNameExample'),
(18, 10, 'None Set Yet', 'New Record', 'SERVER01:/var/www/example', 'SERVER01:/var/www/example'),
(55, 8, 'None Set Yet', 'Will this really save', 'SERVER01:/var/www/example', 'SERVER01:/var/www/example'),
(56, 5, 'None Set Yet', 'New Record', 'SERVER01:/var/www/example', 'SERVER01:/var/www/example');

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE IF NOT EXISTS `level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Store Level of Tasks' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id`, `name`) VALUES
(1, 'low'),
(2, 'medium'),
(3, 'high'),
(4, 'urgent');

-- --------------------------------------------------------

--
-- Table structure for table `notify`
--

CREATE TABLE IF NOT EXISTS `notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `taskId` int(11) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `notify`
--

INSERT INTO `notify` (`id`, `person_id`, `taskId`, `date`) VALUES
(1, 2, 100, NULL),
(2, 3, 100, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE IF NOT EXISTS `people` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drupalId` int(11) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `fname` varchar(55) DEFAULT NULL,
  `lname` varchar(55) DEFAULT NULL,
  `clientId` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `notes` longtext,
  `phone` varchar(25) DEFAULT NULL,
  `staff` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`id`, `drupalId`, `email`, `fname`, `lname`, `clientId`, `status`, `notes`, `phone`, `staff`) VALUES
(1, 0, '', NULL, NULL, NULL, 0, NULL, NULL, NULL),
(2, 1, 'alfrednutile@thinkpadlocal.com', 'Alfred', 'Nutile', NULL, 1, 'Test the First note', '413-555-1212', 1),
(3, 8, 'mailhandlerthree@thinkpadlocal.com', 'Final', 'Missing Name', NULL, 1, 'asdfadsf', NULL, 1),
(4, 9, 'mailhandlerfour@thinkpadlocal.com', 'Test On the fly 3', 'Test On the fly 3', NULL, 1, 'asdfsdfs', NULL, 1),
(5, 10, 'mailhandlerfive@thinkpadlocal.com', 'This Person Saved', 'Testasdfasdf', NULL, 1, 'adsfasdfadfasdfasfsadf', NULL, NULL),
(6, 11, 'mailhandlersix@thinkpadlocal.com', 'Test BC2', 'Test People list', NULL, 1, 'asdfasdfasdfwewe', NULL, 1),
(7, 17, 'mailhandlertwo@thinkpadlocal.com', 'Test BC4', 'Test2', NULL, 1, 'asdfasdf', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID',
  `name` varchar(255) DEFAULT NULL,
  `clientId` int(11) DEFAULT NULL COMMENT 'Client ID',
  `drupalId` int(11) DEFAULT NULL COMMENT 'Original Node Id ',
  `notes` text COMMENT 'Intro notes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='This is the table to store projects and it related to clients' AUTO_INCREMENT=45 ;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `clientId`, `drupalId`, `notes`) VALUES
(18, 'Project-18', 0, 65, ''),
(19, 'Project-19', 0, 29, ''),
(20, 'Project-20', 4, 12, ''),
(21, 'Project-21', 13, 47, ''),
(22, 'Project-22', 0, 50, NULL),
(23, 'Project-23', 3, 25, ''),
(24, 'Project-24', 0, 32, NULL),
(25, 'Project-25', 4, 5, ''),
(26, 'Project-26', 3, 4, ''),
(27, 'Project-27', 6, 13, ''),
(28, 'Project-28', 0, 15, NULL),
(29, 'Project-29', 0, 22, ''),
(30, 'Project-30', 0, 42, NULL),
(31, 'Project-31', 3, 57, 'The git branch for this ...'),
(32, 'Project-32', 0, 33, NULL),
(33, 'Project-33', 0, 40, NULL),
(34, 'Project-34', 12, 16, ''),
(35, 'Project-35', 0, 130, NULL),
(36, 'Project-36', 0, 118, NULL),
(37, 'Project-37', 0, 70, 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo v'),
(38, 'Project-38', 0, 96, NULL),
(39, 'Project-39', 0, 115, NULL),
(40, 'Project-40', 0, 106, 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo v'),
(41, 'Project-41', 0, 112, NULL),
(42, 'Project-42', 0, 119, NULL),
(43, 'Project-43', 0, 123, NULL),
(44, 'Project-44', 0, 113, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE IF NOT EXISTS `quotes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `clientId` int(11) DEFAULT NULL COMMENT 'Related Client',
  `project_name` varchar(255) DEFAULT NULL,
  `exec_summary` text,
  `long_description` tinytext,
  `size` int(11) DEFAULT NULL COMMENT 'The key for the chosen Size',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `line_items_total_hours` int(11) DEFAULT NULL,
  `line_items_total_high_hours` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL COMMENT 'This will reference a status table for quotes',
  `total` int(11) DEFAULT NULL,
  `total_high` int(11) DEFAULT NULL,
  `total_quote` int(11) DEFAULT NULL,
  `total_quote_high` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Parent table to quote info' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `quotes`
--

INSERT INTO `quotes` (`id`, `clientId`, `project_name`, `exec_summary`, `long_description`, `size`, `created`, `line_items_total_hours`, `line_items_total_high_hours`, `status`, `total`, `total_high`, `total_quote`, `total_quote_high`) VALUES
(1, 1, 'Test 1', 'Test Summary', 'Test Long', 1, '2013-04-24 17:01:27', 2, 3, 1, 10, 13, 984, 1280);

-- --------------------------------------------------------

--
-- Table structure for table `quote_assumptions`
--

CREATE TABLE IF NOT EXISTS `quote_assumptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Included or not' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `quote_assumptions`
--

INSERT INTO `quote_assumptions` (`id`, `quote_id`, `description`) VALUES
(1, 1, 'Assume away...'),
(2, 1, 'Assume away... 2'),
(3, 1, 'Assume away... 3');

-- --------------------------------------------------------

--
-- Table structure for table `quote_includes`
--

CREATE TABLE IF NOT EXISTS `quote_includes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL,
  `yesno` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Included or not' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `quote_includes`
--

INSERT INTO `quote_includes` (`id`, `quote_id`, `yesno`, `description`) VALUES
(1, 1, 1, 'Description Here'),
(2, 1, 1, 'Description Here 2'),
(3, 1, 0, 'Description Here Not'),
(4, 1, 0, 'Description Here Not 2');

-- --------------------------------------------------------

--
-- Table structure for table `quote_line_item`
--

CREATE TABLE IF NOT EXISTS `quote_line_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote_id` int(11) NOT NULL COMMENT 'Related Quote',
  `major_feature` varchar(255) DEFAULT NULL,
  `feature_set` varchar(255) DEFAULT NULL,
  `item` varchar(255) NOT NULL,
  `hours` decimal(11,2) DEFAULT NULL,
  `high` decimal(11,2) DEFAULT NULL,
  `doc` int(11) NOT NULL COMMENT 'Degree of Certainty',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 COMMENT='Line items for a quote' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `quote_line_item`
--

INSERT INTO `quote_line_item` (`id`, `quote_id`, `major_feature`, `feature_set`, `item`, `hours`, `high`, `doc`) VALUES
(1, 1, 'Major Feature 1', 'Test 1', 'Test 1 Item', 0.00, 0.00, 1),
(2, 1, 'Major Feature 2', 'Test 2', 'Test 2', 2.00, 2.60, 1);

-- --------------------------------------------------------

--
-- Table structure for table `quote_overhead`
--

CREATE TABLE IF NOT EXISTS `quote_overhead` (
  `id` int(11) NOT NULL,
  `quote_id` int(11) NOT NULL,
  `code` varchar(11) DEFAULT NULL COMMENT 'the 3 letter code used',
  `label` varchar(255) DEFAULT NULL COMMENT 'The label for the select list',
  `percentage` decimal(11,2) DEFAULT NULL,
  `total` decimal(11,2) DEFAULT NULL,
  `totalhigh` decimal(11,2) DEFAULT NULL,
  KEY `quote_index` (`id`,`quote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Store the Quote Overhead info';

--
-- Dumping data for table `quote_overhead`
--

INSERT INTO `quote_overhead` (`id`, `quote_id`, `code`, `label`, `percentage`, `total`, `totalhigh`) VALUES
(0, 1, 'env', 'Environment', 0.05, 0.10, 0.13),
(1, 1, 'cs', 'Concept and Solution', 0.01, 0.02, 0.03),
(2, 1, 'pm', 'Project Managment', 0.20, 0.40, 0.52),
(3, 1, 'cmf', 'Configuration Management, Features', 0.05, 0.10, 0.13),
(4, 1, 'tq', 'Testing & Quality', 0.05, 0.10, 0.13),
(5, 1, 'dep', 'Deployment', 2.50, 5.00, 6.50),
(6, 1, 'train', 'Training', 1.05, 2.10, 2.73),
(7, 1, 'buf', 'Buffer for unforeseen problems', 0.01, 0.02, 0.03);

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drupalId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `drupalId`, `name`) VALUES
(1, 7, 'Done'),
(2, 11, 'Open'),
(3, 8, 'Pending Internal Review'),
(4, 9, 'Pending Client Feedback'),
(5, 67, 'QA Passed Ready to Deploy');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drupalId` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL COMMENT 'Related Project',
  `name` varchar(255) DEFAULT NULL,
  `notes` longtext,
  `created` int(11) DEFAULT NULL,
  `due` int(11) DEFAULT NULL,
  `expected_time` decimal(12,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `meeting` tinyint(1) DEFAULT '0',
  `actual_time` decimal(12,2) DEFAULT NULL,
  `billable` tinyint(1) DEFAULT '0',
  `level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `drupalId`, `project_id`, `name`, `notes`, `created`, `due`, `expected_time`, `status`, `meeting`, `actual_time`, `billable`, `level`) VALUES
(1, 2, 18, 'Fix broken links', 'Lorem ipsum...', 1359435600, NULL, NULL, 2, 0, NULL, NULL, NULL),
(2, 3, 18, 'Close out Account Access but test with Commerce', 'Lorem ipsum...', 1359435600, NULL, NULL, 2, 0, NULL, NULL, NULL),
(3, 4, 0, 'Gravitar icons', 'Lorem ipsum...', 1359479712, NULL, NULL, 2, 1, NULL, NULL, NULL),
(4, 5, 0, 'User name with + sign', 'Lorem ipsum...', 1359479923, NULL, NULL, 1, 1, NULL, NULL, NULL),
(5, 6, 0, 'Extra fields in the form for Other', 'Lorem ipsum...', 1359480313, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(6, 7, 0, 'BrightCover Videos do not size well', 'Lorem ipsum...', 1359480463, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(7, 8, 0, 'Menu Color Changes and other things', 'Lorem ipsum...', 1359485385, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(8, 9, 0, 'Automate the lower menus', 'Lorem ipsum...', 1359485493, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(9, 12, 0, 'Test 2 Thread', 'Lorem ipsum...', 1359503280, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(10, 13, 0, 'Test team notify', 'Lorem ipsum...', 1359504909, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(11, 14, 0, 'Quote Responsive', 'Lorem ipsum...', 1359524137, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(12, 15, 0, 'Security Update', 'Lorem ipsum...', 1359548785, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(13, 16, 0, 'Retainer System', 'Lorem ipsum...', 1359550131, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(14, 17, 0, 'Missing Images', 'Lorem ipsum...', 1359550663, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(15, 18, 0, 'Right hand spotlight cut off on iPad landscape', 'Lorem ipsum...', 1359559444, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(16, 19, 0, 'Banner on home page hover menus go under buttons', 'Lorem ipsum...', 1359567558, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(17, 20, 0, 'Menu Training', 'Lorem ipsum...', 1359571436, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(18, 21, 0, 'Add Custom Report', 'Lorem ipsum...', 1359574053, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(19, 22, 0, 'Rma forum quote', 'Lorem ipsum...', 1359584592, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(20, 23, 0, 'Bullets on home page', 'Lorem ipsum...', 1359642546, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(21, 24, 0, 'Moving sites off of rackspace', 'Lorem ipsum...', 1359647510, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(22, 25, 0, 'umass group limitations', 'Lorem ipsum...', 1359717572, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(23, 26, 0, 'Google Analytics for multiple Domians', 'Lorem ipsum...', 1359717997, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(24, 27, 0, 'Message on RMA is on the bottom after login', 'Lorem ipsum...', 1359719325, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(25, 28, 0, 'URL with .. characters get messed up on download pages', 'Lorem ipsum...', 1359998572, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(26, 29, 0, 'Banner Title 5 px too high on the flexslide', 'Lorem ipsum...', 1359998827, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(27, 30, 0, 'Right side cut off on product page (check showcase as well)', 'Lorem ipsum...', 1359998887, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(28, 31, 0, 'Read more not showing for anonymous', 'Lorem ipsum...', 1360004403, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(29, 32, 0, 'Reply about Videos next steps', 'Lorem ipsum...', 1360004494, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(30, 33, 0, 'Public Health Calendar on left', 'Lorem ipsum...', 1360004589, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(31, 35, 0, 'PH Home page make sure fonts match others', 'Lorem ipsum...', 1360004652, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(32, 36, 0, 'Fac page better indentation in the lower labels', 'Lorem ipsum...', 1360004690, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(33, 37, 0, 'Main Alumni Events Page needs touch up', 'Lorem ipsum...', 1360004745, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(34, 38, 0, 'Outline iCam and moving forward on that. ', 'Lorem ipsum...', 1360004778, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(35, 39, 0, 'Workflow for content going live and perms', 'Lorem ipsum...', 1360004982, NULL, NULL, 3, NULL, NULL, NULL, NULL),
(36, 40, 0, 'Yale Websites', 'Lorem ipsum...', 1360073736, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(37, 41, 0, 'Text on banner in IE', 'Lorem ipsum...', 1360075328, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(38, 42, 0, 'Greater Boston Mapping bug', 'Lorem ipsum...', 1360075396, NULL, NULL, 4, NULL, NULL, NULL, NULL),
(39, 43, 0, 'Umass Communications', 'Lorem ipsum...', 1360075472, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(40, 44, 0, 'Spotlight weight', 'Lorem ipsum...', 1360075888, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(41, 45, 0, 'Private area is seen by public', 'Lorem ipsum...', 1360076035, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(42, 46, 0, 'GHP Map stuff ', 'Lorem ipsum...', 1360076118, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(43, 47, 0, 'Unwanted bullets', 'Lorem ipsum...', 1360090360, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(44, 48, 0, 'SPHHS Access ', 'Lorem ipsum...', 1360093834, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(45, 49, 0, 'Department of Public Health microsite homepage – the word “school” in news & events needs to be changed to “department”', 'Lorem ipsum...', 1360150492, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(46, 50, 0, ' Department of Public Health microsite homepage – formatting issue with “news & events” field (extra paragraph breaks?)', 'Lorem ipsum...', 1360150520, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(47, 51, 0, 'Department of Public Health microsite Events page – has duplicate event listings', 'Lorem ipsum...', 1360150563, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(48, 52, 0, 'Stay connected buttons – mouse hover over “hotspot fields” too tiny on interior pages', 'Lorem ipsum...', 1360150592, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(49, 53, 0, 'Server Error when goes to edit page', 'Lorem ipsum...', 1360161457, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(50, 54, 0, 'Enter GA Code', 'Lorem ipsum...', 1360162051, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(51, 55, 0, 'Tabs style', 'Lorem ipsum...', 1360162461, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(52, 56, 0, 'Duplicate Event on Public Health page', 'Lorem ipsum...', 1360167835, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(53, 57, 0, 'Dual Cookie/Domains', 'Lorem ipsum...', 1360167976, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(54, 58, 0, 'See why drumointor emails are not going out ', 'Lorem ipsum...', 1360170888, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(55, 59, 0, 'Review of Site Status', 'Lorem ipsum...', 1360171064, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(56, 60, 0, 'See why drumonitor is now broke on cron', 'Lorem ipsum...', 1360171787, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(57, 61, 0, 'Review of Site Status', 'Lorem ipsum...', 1360172102, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(58, 62, 0, 'RMA Spam issues', 'Lorem ipsum...', 1360173396, NULL, NULL, 5, NULL, NULL, NULL, NULL),
(59, 63, 0, 'Security Updates Review', 'Lorem ipsum...', 1360173563, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(60, 64, 0, 'Geo bug ', 'Lorem ipsum...', 1360174047, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(61, 65, 0, 'Date Home page sorted Desc', 'Lorem ipsum...', 1360175549, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(62, 66, 0, 'Large File work', 'Lorem ipsum...', 1360176809, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(63, 67, 0, 'Menu item in wrong place see attached', 'Lorem ipsum...', 1360177376, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(64, 68, 0, 'Review of Site Status', 'Lorem ipsum...', 1360180519, NULL, NULL, 3, NULL, NULL, NULL, NULL),
(65, 69, 0, 'Should send me a notice since I am subscribed to ALL Tasks', 'Lorem ipsum...', 1360183982, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(66, 73, 0, 'Brand new task from email client', 'Lorem ipsum...', 1360190404, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(67, 74, 0, 'WestSububan Y Needs apc and monit/munin setup', 'Lorem ipsum...', 1360253331, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(68, 77, 0, 'Use Case #1', 'Lorem ipsum...', 1360268958, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(69, 78, 0, 'Secure PM site ', 'Lorem ipsum...', 1360270444, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(70, 79, 0, 'westsuburbanymca.org does not ping at www', 'Lorem ipsum...', 1360327169, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(71, 132, 0, 'FMK - Please check config for images.fibermark.com', 'Lorem ipsum...', 1360344421, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(72, 142, 0, 'Sending attachments again', 'Lorem ipsum...', 1360350451, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(73, 143, 0, 'Re: poker mpm 2013 site refresh', 'Lorem ipsum...', 1360350601, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(74, 144, 0, 'Varnish issues', 'Lorem ipsum...', 1360528981, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(75, 145, 0, 'Use Case 1 with attachment', 'Lorem ipsum...', 1360529281, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(76, 146, 0, 'youtube video settings to work on http://www.bostonycamps.org/overnight-camp domain', 'Lorem ipsum...', 1360592501, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(77, 147, 0, 'Padding seen on Banner ', 'Lorem ipsum...', 1360593001, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(78, 148, 0, 'font failure ybosont', 'Lorem ipsum...', 1360595812, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(79, 149, 0, 'Security Module', 'Lorem ipsum...', 1360596913, NULL, NULL, 2, NULL, NULL, NULL, NULL),
(80, 150, 0, 'Broken Links', 'Lorem ipsum...', 1360675078, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(81, 151, 0, 'iPad cuts off on right step 3', 'Lorem ipsum...', 1360675472, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(82, 152, 0, 'double check the font title on the billboards both on browser and iPad again.', 'Lorem ipsum...', 1360678078, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(83, 153, 0, 'Font size', 'Lorem ipsum...', 1360683981, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(84, 154, 0, 'Cron job not running the needed data import since 2/6', 'Lorem ipsum...', 1360684352, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(85, 155, 0, 'Market Applications filter shifts down', 'Lorem ipsum...', 1360688654, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(86, 156, 0, 'Staging setup for yboston had an issue', 'Lorem ipsum...', 1360695872, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(87, 157, 0, 'Check if menu is in scope to make unique.', 'Lorem ipsum...', 1360700581, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(88, 159, 0, 'Updating YWeb API Calls', 'Lorem ipsum...', 1360761361, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(89, 160, 0, 'Look into a good documentation tool for both code and txt files', 'Lorem ipsum...', 1360762561, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(90, 161, 0, 'Prepare for Fibermark VD Tool', 'Lorem ipsum...', 1360789360, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(91, 162, 0, 'Natural Doc Install', 'Lorem ipsum...', 1360789475, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(92, 163, 0, 'Bullets on events see attached SPHHS', 'Lorem ipsum...', 1360789681, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(93, 164, 0, 'Bug during comment processing', 'Lorem ipsum...', 1360789919, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(94, 165, 0, 'Webform on FMK missing Canada option', 'Lorem ipsum...', 1360790090, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(95, 166, 0, 'See why fiber mark cache not cleared on deployment', 'Lorem ipsum...', 1360797002, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(96, 167, 0, 'Make burn down chart', 'Lorem ipsum...', 1360798981, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(97, 168, 0, 'Width on fiber mark sometimes causes spotlights to be too compacted', 'Lorem ipsum...', 1360805281, NULL, NULL, 2, NULL, NULL, NULL, 4),
(98, 169, 0, 'report of scrunched up filters on narrow layout', 'Lorem ipsum...', 1360818000, NULL, NULL, 2, NULL, NULL, NULL, 3),
(99, 170, 0, 'Push live and test ticket #169', 'Lorem ipsum...', 1360850869, 1367553600, NULL, 2, NULL, NULL, NULL, 2),
(100, 171, 18, 'Email to Kristen went into her spam not sure why test v1', 'Lorem ipsum...', 1360818000, 1367380800, 2.50, 2, 1, 3.00, 1, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
