-- MySQL dump 10.13  Distrib 5.5.29, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: phprest
-- ------------------------------------------------------
-- Server version	5.5.29-0ubuntu0.12.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `phprest`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `phprest` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `phprest`;

--
-- Table structure for table `assigned`
--

DROP TABLE IF EXISTS `assigned`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assigned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `people_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assigned`
--

LOCK TABLES `assigned` WRITE;
/*!40000 ALTER TABLE `assigned` DISABLE KEYS */;
/*!40000 ALTER TABLE `assigned` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'New system id',
  `drupalId` int(11) DEFAULT NULL COMMENT 'old drupal if needed id',
  `clientName` varchar(125) DEFAULT NULL COMMENT 'Client Name',
  `phone` varchar(35) DEFAULT NULL COMMENT 'Phone',
  `phone2` varchar(35) DEFAULT NULL COMMENT 'Phone',
  `notes` text COMMENT 'Notes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,28,'BioScale','4445554444','8888888888','This is a test existing client with tid 28'),(3,1,'Oops update client name','5555555','53434343','asdfasdfa'),(4,6,'FreshJones',NULL,NULL,NULL),(5,24,'NEW NAME','5555555555','4444444444','gadfgsdfg'),(6,14,'Roy Matheson & Associates',NULL,NULL,NULL),(7,2,'SPHHS',NULL,NULL,NULL),(8,23,'TestGroup',NULL,NULL,NULL),(9,44,'UMASS Communications',NULL,NULL,NULL),(10,35,'West Suburban YMCA',NULL,NULL,NULL),(11,3,'YBoston',NULL,NULL,NULL),(12,17,'YMCA',NULL,NULL,NULL),(13,46,'Test was chrome',NULL,NULL,'test chroma notes');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `task_id` int(11) DEFAULT NULL,
  `comment` longtext,
  `created` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `features`
--

DROP TABLE IF EXISTS `features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `features` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drupalId` int(11) DEFAULT NULL,
  `name` varchar(55) DEFAULT NULL,
  `notes` longtext,
  `related_project` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `features`
--

LOCK TABLES `features` WRITE;
/*!40000 ALTER TABLE `features` DISABLE KEYS */;
INSERT INTO `features` VALUES (37,89,'Bring forward the ability to display and interact with ',NULL,0),(38,111,'Bug',NULL,0),(39,120,'Bugs',NULL,0),(40,81,'Build Release Candidate','',0),(41,101,'Content Entering',NULL,0),(42,72,'Create Computer-generated design compositions','Create initial (rough) computer generated design compositions of the top 2 ideas from the previous feature',0),(43,75,'Create Design Ideas','',0),(44,73,'Create Detailed Composite','',0),(45,78,'Create highly refined composite of selected concept','',0),(46,82,'Create/prepare all files for delivery to production ser','',0),(47,129,'Deployment',NULL,0),(48,98,'Employee Site',NULL,0),(49,122,'Home Page Rework',NULL,0),(50,102,'HTML',NULL,0),(51,105,'Internal Workflow',NULL,0),(52,99,'Maintenance Support',NULL,0),(53,108,'MPM',NULL,0),(54,71,'Present a list of concept ideas for email campaign','Create a text-based list, or quick sketch renderings of brainstormed ideas for the email campaign, along with some ideas for copy, headlings, sub-heads, text, etc.',0),(55,85,'Provide quality assurance','',0),(56,125,'QA Work',NULL,0),(57,93,'Quote Work',NULL,0),(58,87,'Send email release candidate to test group','',0),(59,95,'Server Move',NULL,0),(60,126,'Staged Site Bugs',NULL,0),(61,110,'Tokens',NULL,0),(62,128,'Training',NULL,0),(63,124,'Version 5',NULL,0),(64,92,'[SPHHS] Bug Support','',28),(65,76,'Create Design Concepts','',0),(66,86,'Proof read release candiate','',0),(67,79,'Purchase and license all materials','Purchase and license all stock photography and font usage rights necessary for the project',0),(68,83,'Create emma campaign using FMK template','Using the FiberMark template created on Emma, create the new campaign email with previously generated artwork and files',0),(69,74,'Design Concepts','',0),(70,77,'Design Development','',0),(71,80,'Implementation','',0),(72,84,'Production','',0);
/*!40000 ALTER TABLE `features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hostings`
--

DROP TABLE IF EXISTS `hostings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hostings` (
  `id` int(75) NOT NULL AUTO_INCREMENT,
  `clientId` int(11) NOT NULL,
  `levelId` varchar(256) NOT NULL,
  `notes` text NOT NULL,
  `backuplocation1` varchar(256) NOT NULL,
  `backuplocation2` varchar(256) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1 COMMENT='Storing hosting info';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hostings`
--

LOCK TABLES `hostings` WRITE;
/*!40000 ALTER TABLE `hostings` DISABLE KEYS */;
INSERT INTO `hostings` VALUES (5,1,'6','test','/var/www/1','/var/www/11'),(6,3,'2','test put','/var/www/1','/var/www/11'),(7,13,'1','1914 translation by H. Rackham\n\n\"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?\"\n\nSection 1.10.33 of \"de Finibus Bonorum et Malorum\", written by Cicero in 45 BC\n\n\"At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.\"\n\n','test1','Rackspace:imageNameExample'),(8,12,'1','This is a new hosting package for YMCA test 2','Server01:/var/www/example','Rackspace:imageNameExample'),(9,11,'None Set','This is new','Server01:/var/www/example','Rackspace:imageNameExample'),(10,7,'1','sphhs test','Server01:/var/www/example','Rackspace:imageNameExample'),(11,1,'2','test 2 forms after git merge ','/var/www/1','/var/www/11'),(12,4,'None Set','Any Notes?','Server01:/var/www/example','Rackspace:imageNameExample'),(13,6,'None Set','Any Notes?','Server01:/var/www/example','Rackspace:imageNameExample'),(18,10,'None Set Yet','New Record','SERVER01:/var/www/example','SERVER01:/var/www/example'),(55,8,'None Set Yet','Will this really save','SERVER01:/var/www/example','SERVER01:/var/www/example');
/*!40000 ALTER TABLE `hostings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `level`
--

DROP TABLE IF EXISTS `level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Store Level of Tasks';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `level`
--

LOCK TABLES `level` WRITE;
/*!40000 ALTER TABLE `level` DISABLE KEYS */;
/*!40000 ALTER TABLE `level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notify`
--

DROP TABLE IF EXISTS `notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `taskId` int(11) DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notify`
--

LOCK TABLES `notify` WRITE;
/*!40000 ALTER TABLE `notify` DISABLE KEYS */;
INSERT INTO `notify` VALUES (1,2,100,NULL),(2,3,100,NULL);
/*!40000 ALTER TABLE `notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drupalId` int(11) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `fname` varchar(55) DEFAULT NULL,
  `lname` varchar(55) DEFAULT NULL,
  `clientId` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `notes` longtext,
  `phone` varchar(25) DEFAULT NULL,
  `staff` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (1,0,'',NULL,NULL,NULL,0,NULL,NULL,NULL),(2,1,'alfrednutile@thinkpadlocal.com','Alfred','Nutile',NULL,1,'Test the First note','413-230-4767',1),(3,8,'mailhandlerthree@thinkpadlocal.com','Final','Missing Name',NULL,1,'asdfadsf',NULL,1),(4,9,'mailhandlerfour@thinkpadlocal.com','Test On the fly 3','Test On the fly 3',NULL,1,'asdfsdfs',NULL,1),(5,10,'mailhandlerfive@thinkpadlocal.com','This Person Saved','Testasdfasdf',NULL,1,'adsfasdfadfasdfasfsadf',NULL,NULL),(6,11,'mailhandlersix@thinkpadlocal.com','Test BC2','Test People list',NULL,1,'asdfasdfasdfwewe',NULL,1),(7,17,'mailhandlertwo@thinkpadlocal.com','Test BC4','Test2',NULL,1,'asdfasdf',NULL,NULL);
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique ID',
  `name` varchar(255) DEFAULT NULL,
  `clientId` int(11) DEFAULT NULL COMMENT 'Client ID',
  `drupalId` int(11) DEFAULT NULL COMMENT 'Original Node Id ',
  `notes` text COMMENT 'Intro notes',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1 COMMENT='This is the table to store projects and it related to clients';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (18,'Add on work',0,65,''),(19,'BioScale Bucket',0,29,''),(20,'Build Project Website',4,12,''),(21,'Chroma Bucket',13,47,''),(22,'Content Entering System',0,50,NULL),(23,'Demo iPad to Managers',3,25,''),(24,'DruMonitor',0,32,NULL),(25,'FJ Bucket',4,5,''),(26,'FMK Bucket',3,4,''),(27,'RMA Bucket',6,13,''),(28,'SPHHS Website',0,15,NULL),(29,'TestOG',0,22,''),(30,'UMass Communications Bucket',0,42,NULL),(31,'Virtual Design Tool Box',3,57,'The git branch for this is feature_virtual_design_tool\r\n\r\nThere google doc for this is\r\nhttps://docs.google.com/a/freshjones.com/spreadsheet/ccc?key=0Au2eYRqcN2oKdDI2TWNtczEtV1lLY0ljMHhkNWYtU1E#gid=4\r\nIncludes burn down chart (coming today)'),(32,'West Suburban Bucket',0,33,NULL),(33,'YBoston Bucket',0,40,NULL),(34,'YBoston Camps',12,16,''),(35,'Deployment Workflow',0,130,NULL),(36,'FiberMark - Website',0,118,NULL),(37,'FiberMark - Website Plug Email Campaign',0,70,'Organization\r\nFibermark LLC\r\n\r\nOrganization/Purpose\r\nFiberMark materials provide an endless array of design and performance possibilities for applications in the performance boards, covering solutions, luxury packaging, technical/industrial, security, print media and graphic design markets.\r\n\r\nProject Purpose\r\nPromote the new website and its features in a series of email campaigns, by creating an intriguing email blast that will entice recipients to open, view and click through to see the new website.\r\n\r\nProject Overview\r\nDesign and Develop an emma email campaign using the template developed within emma to promote the website in an intriguing and enticing way that is more artistic and curious than straight-forward in message. This email will be a one-off campaign and will promote the site as a whole.\r\n\r\nProject Scope\r\n   What\'s included\r\n   * Design concepts 2 iterations\r\n   * Copy writing concepts\r\n   * 2 refinement iterations of selected concept\r\n   * 1 iteration - art production of final direction\r\n   * 1 iteration of proof reading\r\n   * 1 iteration of template setup within myEmma system\r\n   * Quality assurance of email campaign\r\n \r\n   What\'s not included\r\n   * Creation and assignment of audiences to campaign\r\n   * Testing and Sending Email (Client responsibility)\r\n   * Statistics and tracking (Client responsibility) \r\n\r\nTarget Market\r\n   * Designers\r\n   * Specifiers\r\n   * Brand-owners\r\n   * Commercial Printers\r\n   * Brand-owners\r\n\r\nContent\r\nFreshJones responsible for content development, and concepts could/should be derived from brainstorm\r\n'),(38,'Fibermark Employee Site',0,96,NULL),(39,'KindleFarm Website',0,115,NULL),(40,'Move Sites',0,106,'<p>Google doc</p><p><a href=\"https://docs.google.com/a/freshjones.com/spreadsheet/lv?key=0AmGk6RZgp6wrdHBibEtfYWFvVVNtSTFBZThGLUxiSEE\">https://docs.google.com/a/freshjones.com/spreadsheet/lv?key=0AmGk6RZgp6wrdHBibEtfYWFvVVNtSTFBZThGLUxiSEE</a></p>'),(41,'Old Colony YMCA Website',0,112,NULL),(42,'Polsci Maintenance',0,119,NULL),(43,'Slice Template',0,123,NULL),(44,'UMass Gateway',0,113,NULL);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drupalId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` VALUES (1,7,'Done'),(2,11,'Open'),(3,8,'Pending Internal Review'),(4,9,'Pending Client Feedback'),(5,67,'QA Passed Ready to Deploy');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `drupalId` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL COMMENT 'Related Project',
  `name` varchar(255) DEFAULT NULL,
  `assigned` int(11) DEFAULT NULL,
  `notify` int(11) DEFAULT NULL,
  `notes` longtext,
  `created` int(11) DEFAULT NULL,
  `due` int(11) DEFAULT NULL,
  `expected_time` decimal(12,2) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `meeting` tinyint(1) DEFAULT '0',
  `actual_time` decimal(12,2) DEFAULT NULL,
  `billable` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (1,2,18,'Fix broken links',2,NULL,'Hi Al,\r\n\r\nHere is the list and the snapshot of the 404s. Thanks!\r\n\r\nhttp://www.fibermark.com/environment\r\n\r\nKind regards,\r\nChloe\r\n\r\nChloe Jones\r\nFreshJones Creative\r\n413.475.1810 (o)\r\n413.522.6351 (m)\r\nchloe@freshjones.com\r\n\r\n\r\n\r\n\r\n\r\n',1359473434,NULL,NULL,2,1,NULL,NULL),(2,3,18,'Close out Account Access but test with Commerce',2,NULL,'Hi there,\r\nHere is another example of a request for account.  Could you update the email address from qfmk to either you or I or both so as not to confuse the other recipients on the qfmk alias?\r\nAlso, is there a way to block this so people can\'t request accounts... I\'m not sure how/where they are doing this.  Would adding something like a captcha work?\r\nThanks\r\nDanielle\r\n\r\n-----Original Message-----\r\nFrom: qfmk@fibermark.com [mailto:qfmk@fibermark.com] \r\nSent: Sunday, January 27, 2013 10:51 PM\r\nTo: Alias- QFMK\r\nSubject: Account details for sibealbranch at FiberMark (pending admin approval)\r\n\r\nsibealbranch has applied for an account.\r\n\r\nhttp://www.fibermark.com/users/sibealbranch/edit\r\n',1359474886,NULL,NULL,2,1,NULL,NULL),(3,4,0,'Gravitar icons',2,NULL,'pull in the images',1359479712,NULL,NULL,2,1,NULL,NULL),(4,5,0,'User name with + sign',2,NULL,'Morning Amanda,\r\nWe will have a morning meeting about the schedule and I will mention this task to see when it can get done.\r\n\r\nOne concern though is when you said \"The email field currently allows a + sign\" this is true but to be clear the user may not get this email if for some reason their email provider does not allow the standard + sign.\r\nYour example email  seed+1001@roymatheson.com may never make it to a user if their system, for some odd reason, is not following the more standard practice of allowing that. (http://en.wikipedia.org/wiki/Email_addresses#Address_tags)\r\nSo they could never reset their password or get notifications. Most emails systems do allow + signs that do not alter the recipient final destination. \r\nMaybe it is a non issue but just a thought.\r\nDo you want to talk on the phone today to clarify?\r\n\r\nThanks\r\nAl\r\n\r\n-----------------------\r\nFreshJones Creative\r\n413.475.1810 (o) x804\r\nal@freshjones.com\r\n\r\n\r\nOn Jan 28, 2013, at 2:30 PM, Amanda Winchester <amanda@roymatheson.com> wrote:\r\n\r\nWe would like to go ahead with this.\r\n\r\nJust to clarify the usernames need to allow a plus sign. The email field currently allows a + sign, so this field doesn\'t need to change.\r\n\r\nWhen will you be able to work on this?\r\n\r\nThank you,\r\n\r\nAmanda Winchester\r\nDirector of Technology\r\n\r\n\r\n? Roy Matheson & Associates  P.O. Box 492, Keene, NH, 03431-0492\r\n? Toll Free: 1-800-443-7690 • Int\'l: 1-603-358-6525 • Fax: 1-603-358-0116\r\n? Amanda@roymatheson.com • www.roymatheson.com   \r\n     \r\n\r\n\r\nOn Mon, Jan 28, 2013 at 2:10 PM, Alfred Nutile <al@freshjones.com> wrote:\r\nSorry Amanda,\r\nI meant to review this this morning,\r\nHere is what I am estimating\r\n2.5 Hours to do a hook_alter on the drupal user form or see if there is a module out there.\r\nAfter that setting it up so you can test it on a staged site and then deploy it to the live site.\r\n\r\nLet me know if you would like me to move forward with it.\r\n\r\nHere is the summary of the technical goals\r\n1. All new usernames can have a + sign in them\r\n2. This will not effect the emails since those will be entered as normal emails.\r\n\r\nThanks\r\nAl\r\n\r\n-----------------------\r\nFreshJones Creative\r\n413.475.1810 (o) x804\r\nal@freshjones.com\r\n\r\n\r\nOn Jan 28, 2013, at 1:31 PM, Amanda Winchester <amanda@roymatheson.com> wrote:\r\n\r\nHello, \r\nCan I get an update on this? How long is it going to take? \r\n\r\nThank you,\r\n\r\nAmanda Winchester\r\nDirector of Technology\r\n\r\n\r\n? Roy Matheson & Associates  P.O. Box 492, Keene, NH, 03431-0492\r\n? Toll Free: 1-800-443-7690 • Int\'l: 1-603-358-6525 • Fax: 1-603-358-0116\r\n? Amanda@roymatheson.com • www.roymatheson.com   \r\n     \r\n\r\n\r\nOn Fri, Jan 25, 2013 at 10:54 AM, Amanda Winchester <amanda@roymatheson.com> wrote:\r\nI will be adding one user at a time.\r\n\r\nThe usernames will look like: seed+1001@roymatheson.com\r\nwith seed+1001 as the password.\r\n\r\nThank you,\r\n\r\nAmanda Winchester\r\nDirector of Technology\r\n\r\n\r\n? Roy Matheson & Associates  P.O. Box 492, Keene, NH, 03431-0492\r\n? Toll Free: 1-800-443-7690 • Int\'l: 1-603-358-6525 • Fax: 1-603-358-0116\r\n? Amanda@roymatheson.com • www.roymatheson.com  \r\n     \r\n\r\n\r\nOn Fri, Jan 25, 2013 at 10:51 AM, Alfred Nutile <al@freshjones.com> wrote:\r\nThanks Amanda,\r\nOne last question is are you using any special modules to add users in bulk?\r\nI just want to make sure to get all interfaces to work and tested as working.\r\n\r\n1. The user registration page. (seems this is not a concern since you are adding the usernames not the user?)\r\n2. The admin user page where you add 1 user at a time.\r\n\r\nIs there a bulk interface you are using to add more than one user at a time?\r\n\r\nSo an example username, that you are sending out, would be user@example.com+\r\n\r\nThanks\r\nAl\r\n\r\nOn Jan 25, 2013, at 10:43 AM, Amanda Winchester <amanda@roymatheson.com> wrote:\r\n\r\nWe just want to \"allow\" people to use a plus sign in their username. No other settings should change. They do not have to have a plus sign, we just want the option to be there. Also, they should still be able to use an email address, as the usernames that we are creating are going to be email addresses with plus signs in them.\r\n\r\nAny usernames that are already created must not be changed.\r\n\r\nThank you,\r\n\r\nAmanda Winchester\r\nDirector of Technology\r\n\r\n\r\n? Roy Matheson & Associates  P.O. Box 492, Keene, NH, 03431-0492\r\n? Toll Free: 1-800-443-7690 • Int\'l: 1-603-358-6525 • Fax: 1-603-358-0116\r\n? Amanda@roymatheson.com • www.roymatheson.com   \r\n     \r\n\r\n\r\nOn Fri, Jan 25, 2013 at 10:34 AM, Alfred Nutile <al@freshjones.com> wrote:\r\nMorning Amanda,\r\nSounds possible.\r\nLet me just make sure I understand the goals.\r\n\r\n1. All new usernames can or must have a + sign at the end/beginning of them?\r\n2. All existing usernames should be updated to match this?\r\n3. A user will have to remember the + when logging in to the site?\r\n4. Users are not using their email as a username, if they are what should we do about those or where would we add the +\r\n\r\nIf you help to clarify the above then I can follow up with a sense of how long it will take.\r\n\r\nThanks\r\nAl\r\n\r\nOn Jan 25, 2013, at 10:30 AM, Chloe Jones <chloe@freshjones.com> wrote:\r\n\r\nHi Amanda,\r\n\r\nI will ask Al and get back to you shortly.\r\n\r\nKind regards,\r\nChloe\r\n\r\nChloe Jones\r\nFreshJones Creative\r\n413.475.1810 (o)\r\n413.522.6351 (m)\r\nchloe@freshjones.com\r\n\r\n\r\n\r\n\r\n\r\nOn Jan 25, 2013, at 10:19 AM, Amanda Winchester wrote:\r\n\r\nHi Chloe, is it possible to change the settings on our website to allow plus signs in the username field? We are working on a project and need to create multiple usernames for the website but they will all need to have + in them. If this can be done I would really appreciate it :-)\r\n\r\nThank you,\r\n\r\nAmanda Winchester\r\nDirector of Technology\r\n\r\n\r\n? Roy Matheson & Associates  P.O. Box 492, Keene, NH, 03431-0492\r\n? Toll Free: 1-800-443-7690 • Int\'l: 1-603-358-6525 • Fax: 1-603-358-0116\r\n? Amanda@roymatheson.com • www.roymatheson.com  \r\n     ',1359479923,NULL,NULL,1,1,NULL,NULL),(5,6,0,'Extra fields in the form for Other',2,NULL,NULL,1359480313,NULL,NULL,1,NULL,NULL,NULL),(6,7,0,'BrightCover Videos do not size well',2,NULL,'need to consider a view',1359480463,NULL,NULL,1,NULL,NULL,NULL),(7,8,0,'Menu Color Changes and other things',2,NULL,'Kristen noted\r\nTry making it the medium green:#01a490\r\n\r\nDONE -      Round navigation drop downs – is this possible?\r\nDONE -      P on camp is cut off on internal page countdown\r\nDONE -      “contact” not fitting on top nav\r\nPENDING REVIEW -      Front page secondary spotlight spacing\r\nPENDING REVIEW -      Bullet alignment\r\n---http://www.ymcaboston.org:8080/ymca-camp-disabled/pleasantvalleycamp\r\nDONE -      Top nav coloring/lines/arrow\r\n\r\nAlso\r\nNOTIFIED CLIENT Is there a way to make the top line of the bottom nav (register, site map, privacy etc) specific to camp?\r\n\r\n\r\nRound nav is fine will push that up with the color work.\r\n--Okay next push tomorrow\r\nP on camp is cut off on internal page countdown\r\n--Okay next push tomorrow\r\n “contact” not fitting on top nav\r\n--Seems okay in Chrome which is where you reported it. What browser are you seeing it in now?\r\nFront page secondary spotlight spacing\r\n--Thought I got this as well? Maybe some more details I can then wrap it up.\r\nTop Nav\r\n--Should be in tomorrows push',1359485385,NULL,NULL,1,NULL,NULL,NULL),(8,9,0,'Automate the lower menus',2,NULL,'Make the lower menus automated from the top 3\r\n\r\n\r\nAlso update the Is there a way to make the top line of the bottom nav (register, site map, privacy etc) specific to camp?\r\n',1359485493,NULL,NULL,1,NULL,NULL,NULL),(9,12,0,'Test 2 Thread',2,NULL,'test new thread',1359503280,NULL,NULL,1,NULL,NULL,NULL),(10,13,0,'Test team notify',2,NULL,'Made by user al@freshjones.com\r\nShould notify testuser and admin',1359504909,NULL,NULL,1,NULL,NULL,NULL),(11,14,0,'Quote FMK Responsive',2,NULL,NULL,1359524137,NULL,NULL,1,NULL,NULL,NULL),(12,15,0,'Security Update',2,NULL,'in need',1359548785,NULL,NULL,2,NULL,NULL,NULL),(13,16,0,'Retainer System',2,NULL,NULL,1359550131,NULL,NULL,2,NULL,NULL,NULL),(14,17,0,'Missing Images',2,NULL,'Begin forwarded message:\r\n\r\nFrom: Danielle Cutler <dcutler@fibermark.com>\r\nSubject: RE: Separate issue from the 404\r\nDate: January 29, 2013 5:27:50 PM EST\r\nTo: Alfred Nutile <alfrednutile@gmail.com>\r\nCc: Chloe Jones <chloe@freshjones.com>, Danielle Cutler <dcutler@fibermark.com>\r\n\r\nThe image I sent earlier showed my screen shot of the machinery page…  also noting that Chloe and I were looking at that page yesterday and didn’t see this issue.\r\nAnother example, here is what the app page looks like:\r\n\r\n \r\nFrom: Alfred Nutile [mailto:alfrednutile@gmail.com] \r\nSent: Tuesday, January 29, 2013 5:25 PM\r\nTo: Danielle Cutler\r\nCc: Chloe Jones\r\nSubject: Re: Separate issue from the 404\r\n \r\nSo it seems this ticket is now two issues.\r\nI only knew about the 404. So to be clear are you are saying at these two URLs\r\nhttp://www.fibermark.com/design/apps\r\nhttp://www.fibermark.com/about/fibermark-uk-red-bridge/machinery\r\nAll spotlight images are missing?\r\nEither way I am going to make a new email thread so this one only deals with 404 issue.\r\nUnless I am reading this incorrectly?\r\n \r\n \r\n\r\nOn Tue, Jan 29, 2013 at 5:05 PM, Danielle Cutler <dcutler@fibermark.com> wrote:\r\nOK, but I think what I attached in my pic is a separate issue… all the pictures and icons have disappeared…\r\nhttp://www.fibermark.com/about/fibermark-uk-red-bridge/machinery\r\nI checked another page as well and I see the same issue\r\nhttp://www.fibermark.com/design/apps\r\n \r\nI know these spotlights in the 404 list were all working at one time… and I know these pictures were there just yesterday because Chloe, you and I were on the machinery page specifically.\r\nAre we being hacked?\r\n \r\nFrom: Chloe Jones [mailto:chloe@freshjones.com] \r\nSent: Tuesday, January 29, 2013 3:37 PM\r\nTo: Danielle Cutler\r\nCc: Alfred Nutile\r\nSubject: Re: [Task] 404 Fix\r\n \r\nYes. I\'ve given all the list of 16 404s and he should be finishing those today.\r\n \r\nKind regards,\r\nChloe\r\n \r\nChloe Jones\r\nFreshJones Creative\r\n413.475.1810 (o)\r\n413.522.6351 (m)\r\nchloe@freshjones.com\r\n \r\n \r\n \r\n\r\n \r\nOn Jan 29, 2013, at 3:12 PM, Danielle Cutler wrote:\r\n \r\n\r\nThank you.  Will that fix what I\'m seeing on the pages as well... (Chloe, weren’t these YouTube and machine pics on the site when we looked just yesterday?)\r\n<image001.png>\r\n \r\n-----Original Message-----\r\nFrom: Alfred Nutile [mailto:alfrednutile@gmail.com] \r\nSent: Tuesday, January 29, 2013 3:00 PM\r\nTo: Danielle Cutler\r\nCc: Chloe Jones\r\nSubject: [Task] 404 Fix\r\n \r\nI will push this up in the morning as I push up the \"Other\" fields as well.\r\n \r\nAl\r\n \r\n \r\n________________________________________________________________________\r\nThis Email has been scanned for all viruses by PAETEC\'s Hosted E-mail Security Services, utilizing MessageLabs proprietary SkyScan infrastructure. For more information on a proactive anti-virus service working around the clock, around the globe, visit http://www.paetec.com.\r\n________________________________________________________________________\r\n \r\n \r\n\r\n________________________________________________________________________\r\nThis Email has been scanned for all viruses by PAETEC\'s Hosted E-mail Security Services, utilizing MessageLabs proprietary SkyScan infrastructure. For more information on a proactive anti-virus service working around the clock, around the globe, visit http://www.paetec.com.\r\n________________________________________________________________________\r\n \r\n\r\n________________________________________________________________________\r\nThis Email has been scanned for all viruses by PAETEC\'s Hosted E-mail Security Services, utilizing MessageLabs proprietary SkyScan infrastructure. For more information on a proactive anti-virus service working around the clock, around the globe, visit http://www.paetec.com.\r\n________________________________________________________________________\r\n',1359550663,NULL,NULL,1,NULL,NULL,NULL),(15,18,0,'Right hand spotlight cut off on iPad landscape',2,NULL,'see attached',1359559444,NULL,NULL,1,NULL,NULL,NULL),(16,19,0,'Banner on home page hover menus go under buttons',2,NULL,NULL,1359567558,NULL,NULL,1,NULL,NULL,NULL),(17,20,0,'Menu Training w/ Patrick',2,NULL,NULL,1359571436,NULL,NULL,1,NULL,NULL,NULL),(18,21,0,'Add Custom Report',2,NULL,NULL,1359574053,NULL,NULL,1,NULL,NULL,NULL),(19,22,0,'Rma forum quote',2,NULL,NULL,1359584592,NULL,NULL,1,NULL,NULL,NULL),(20,23,0,'Bullets on home page',2,NULL,'see attached ',1359642546,NULL,NULL,1,NULL,NULL,NULL),(21,24,0,'Moving sites off of rackspace',2,NULL,NULL,1359647510,NULL,NULL,1,NULL,NULL,NULL),(22,25,0,'umass group limitations',2,NULL,'This 7.x-3 version seems to have 2 limitations that are really tough to deal with.\r\n\r\n1. http is the default url for the video js script so it does not work on https in Chrome\r\nhttp://drupal.org/node/1705826\r\n\r\n2. the lack of control over width and height per insert means the user can not really predict how the video will look if the right sidebar has content.\r\nhttp://drupal.org/node/1883738 talks a bit about responsive integration though I am not sure if it will solve the problem.\r\nExample, these pages \r\nhttps://umwebdev.oit.umass.edu/sphhs/online/mph-php/prospective-students may have a spotlight bar on the right which would then show under the video.\r\nI posted about it here\r\nhttp://drupal.org/node/1899040 but with no reply.\r\n\r\nAnd you can not put two fields on one node of the Brightcove type for some reason.\r\n\r\nSo right now there is now way to deal with a page that may be wide in some areas and narrow in others.\r\n\r\n\r\nJust wondering, since UMASS seems to be really behind the Brightcove usage do you have any advice on how to deal with these limitations?',1359717572,NULL,NULL,1,NULL,NULL,NULL),(23,26,0,'Google Analytics for multiple Domians',2,NULL,'GA needs to work for both domains though one site.\r\n\r\nThe site http://bostonycamps.org/home actually has 2 cpdes\r\n<code>\r\n<script type=\"text/javascript\">\r\nvar gaJsHost = ((\"https:\" == document.location.protocol) ? \"https://ssl.\" : \"http://www.\");\r\ndocument.write(unescape(\"%3Cscript src=\'\" + gaJsHost + \"google-analytics.com/ga.js\' type=\'text/javascript\'%3E%3C/script%3E\"));\r\n</script>\r\n<script type=\"text/javascript\">\r\ntry {\r\nvar pageTracker = _gat._getTracker(\"UA-12712258-1\");\r\npageTracker._setDomainName(\".bostonycamps.org\");\r\npageTracker._trackPageview();\r\n\r\nvar rollupTracker = _gat._getTracker(\"UA-12712275-1\");\r\nrollupTracker._setDomainName(\".bostonycamps.org\");\r\nrollupTracker._trackPageview();\r\n</code>',1359717997,NULL,NULL,1,NULL,NULL,NULL),(24,27,0,'Message on RMA is on the bottom after login',2,NULL,'see attached. After a user registers.',1359719325,NULL,NULL,2,NULL,NULL,NULL),(25,28,0,'URL with .. characters get messed up on download pages',2,NULL,'See the machine page. ',1359998572,NULL,NULL,1,NULL,NULL,NULL),(26,29,0,'Banner Title 5 px too high on the flexslide',2,NULL,'any page with a banner the title is too high see attached.',1359998827,NULL,NULL,1,NULL,NULL,NULL),(27,30,0,'Right side cut off on product page (check showcase as well)',2,NULL,'see attached',1359998887,NULL,NULL,1,NULL,NULL,NULL),(28,31,0,'Read more not showing for anonymous',2,NULL,'placed some code in \r\nviews-view-field--spotlights--field-read-more.tpl.php\r\n\r\nand this took care of it.\r\n\r\nNot ideal and not sure why this permission level issue showed up for a non blocked bit of content.\r\n',1360004403,NULL,NULL,1,NULL,NULL,NULL),(29,32,0,'Reply about Videos next steps',2,NULL,'wide/not wide\r\nhttp versus https\r\nis wysiwyg working now with media module',1360004494,NULL,NULL,1,NULL,NULL,NULL),(30,33,0,'Public Health Calendar on left',2,NULL,NULL,1360004589,NULL,NULL,1,NULL,NULL,NULL),(31,35,0,'PH Home page make sure fonts match others',2,NULL,NULL,1360004652,NULL,NULL,1,NULL,NULL,NULL),(32,36,0,'Fac page better indentation in the lower labels',2,NULL,'Labels in the full person page have odd indent',1360004690,NULL,NULL,1,NULL,NULL,NULL),(33,37,0,'Main Alumni Events Page needs touch up',2,NULL,'Main Alumni Events Page needs touch up\r\n\r\n--no bullets\r\n\r\n--float link right and make that nice red button\r\n',1360004745,NULL,NULL,1,NULL,NULL,NULL),(34,38,0,'Outline iCam and moving forward on that. ',2,NULL,'Outline iCam and moving forward on that.\r\n\r\n--microsite spin off\r\n',1360004778,NULL,NULL,1,NULL,NULL,NULL),(35,39,0,'Workflow for content going live and perms',2,NULL,'<p>--workflow they are in role faculty --they can edit any node --patrick has to push it live. --make sure we have the tools needed ----Chloe email first with a moderation workflow Question Og module and group level access Role Levels --Admin --Content Admin --Faculty --Authenticate</p>',1360004982,NULL,NULL,3,NULL,NULL,NULL),(36,40,0,'Yale Websites',2,NULL,'Nancy Flowers-Mangs <nancy.flowers-mangs@yale.edu>\r\n\r\nHi Alfred, since we have worked with you in the past, I have added freshjones to the Drupal Partners list. Here is an email I sent previously to potential partners.  Chloe, please feel free to contact me if you have any questions.\r\n \r\nAbout YaleSites\r\nThe YaleSites service (powered by Drupal) is designed to enable the Yale Community to easily create and manage web content. Recently updated to Drupal 7, the service is hosted on Yale’s secure web servers and maintained by Yale’s ITS Systems group. This is the preferred hosting environment as it is cost-effective and simplifies the installation process, security, and ongoing maintenance of YaleSites. http://yalesites.yale.edu/  \r\nYaleSites Development Guidelines\r\nMost of the work requested of Drupal Partners is for the YaleSite Custom offering. Details for working in the YaleSites environment can be found on the YaleSites How-to Guide. Please read and review the following guidelines (http://yalesites.yale.edu/book/yalesites-custom) to ensure you understand the YaleSites development environment. Prior to any development, you will be asked to sign the Custom Site Agreement http://yalesites.yale.edu/yalesites-custom-agreement.  All code is checked prior to it being moved to the production environment.\r\nModules\r\nThe YaleSites service includes a comprehensive list of modules to provide added functionality.  All sites built within the YaleSites infrastructure must use modules available within this infrastructure.  A comprehensive list of modules can be found athttp://yalesites.yale.edu/module-listing. In the event additional modules are needed, they will be considered by request. However, modules that duplicate functionality will not be considered.\r\n \r\nWorking with the OPAC Team\r\nSite development is a partnership with the OPAC Web Development team and we are available for consultation prior to site development. Our goal is to develop a team of partners who help build sustainable sites that allow non-technical faculty, students and staff to maintain and manage their sites.  \r\n \r\nBy replying to this email, you agree to the terms and conditions stated on yalesites.yale.edu. Upon receipt, we will list you as a Drupal Partner. We ask that you do not solicit work directly; rather we will direct people to the Drupal Partners listing and guide them based on their needs.  In the event you are contacted by someone directly, please let us know so we can ensure the process is understood and everything is set up properly.\r\n \r\nWe look forward to working with you in the future.',1360073736,NULL,NULL,1,NULL,NULL,NULL),(37,41,0,'Text on banner in IE',2,NULL,NULL,1360075328,NULL,NULL,1,NULL,NULL,NULL),(38,42,0,'Greater Boston Mapping bug',2,NULL,'Location stuff not working',1360075396,NULL,NULL,4,NULL,NULL,NULL),(39,43,0,'Umass Communications',2,NULL,'date sorting...',1360075472,NULL,NULL,1,NULL,NULL,NULL),(40,44,0,'Spotlight weight',2,NULL,'not sticking\r\nwestsuburban',1360075888,NULL,NULL,1,NULL,NULL,NULL),(41,45,0,'Private area is seen by public',2,NULL,'<p>need to review with Billy</p>',1360076035,NULL,NULL,1,NULL,NULL,NULL),(42,46,0,'GHP Map stuff ',2,NULL,NULL,1360076118,NULL,NULL,1,NULL,NULL,NULL),(43,47,0,'Unwanted bullets',2,NULL,'I noticed that certain pages:\r\n \r\n*the faculty and staff directory listings\r\n*the tab headers on the tabbed browsing pages (online MPH-PHP and MPH-N prospective and current students)\r\n*the alumni events page\r\n \r\nAll have small bullets appearing next to each entry.\r\n \r\nI believe I mentioned this item in the context of the alumni events page in yesterday’s conference call, but I noticed it appearing on the other pages as well.',1360090360,NULL,NULL,1,NULL,NULL,NULL),(44,48,0,'SPHHS Access ',2,NULL,'see if OG access off helps with those fields.',1360093834,NULL,NULL,1,NULL,NULL,NULL),(45,49,0,'Department of Public Health microsite homepage – the word “school” in news & events needs to be changed to “department”',2,NULL,NULL,1360150492,NULL,NULL,1,NULL,NULL,NULL),(46,50,0,' Department of Public Health microsite homepage – formatting issue with “news & events” field (extra paragraph breaks?)',2,NULL,NULL,1360150520,NULL,NULL,1,NULL,NULL,NULL),(47,51,0,'Department of Public Health microsite Events page – has duplicate event listings',2,NULL,NULL,1360150563,NULL,NULL,1,NULL,NULL,NULL),(48,52,0,'Stay connected buttons – mouse hover over “hotspot fields” too tiny on interior pages',2,NULL,NULL,1360150592,NULL,NULL,1,NULL,NULL,NULL),(49,53,0,'Server Error when goes to edit page',2,NULL,'I’m trying to update the homepage messaging for the Health Policy and Management microsite. I searched under “find content” and found what I assume to be the HPM basic page that contains the messaging. However, when I click on the link, the page does not open. This is the link I’m trying to access:\r\n \r\nhttps://umwebdev.oit.umass.edu/sphhs/health-policy-and-management-22\r\n \r\nCan you check to see if there’s an error with that page or if there’s a permission issue?',1360161457,NULL,NULL,1,NULL,NULL,NULL),(50,54,0,'Enter GA Code',2,NULL,'UA-23374682-1',1360162051,NULL,NULL,1,NULL,NULL,NULL),(51,55,0,'Tabs style',2,NULL,'see design',1360162461,NULL,NULL,1,NULL,NULL,NULL),(52,56,0,'Duplicate Event on Public Health page',2,NULL,'uhg\r\nviews sucks.\r\n',1360167835,NULL,NULL,1,NULL,NULL,NULL),(53,57,0,'Dual Cookie/Domains',2,NULL,'Due to the dual domains it would be best for now to login here\r\nhttp://www.bostonycamps.org:8080/user\r\nThis way you are editing under the same domain.\r\nI will update the settings file to allow shared domains for your login cookies.',1360167976,NULL,NULL,2,NULL,NULL,NULL),(54,58,0,'See why drumointor emails are not going out ',2,NULL,'they only go out when I open the browser and then are empty..',1360170888,NULL,NULL,2,NULL,NULL,NULL),(55,59,0,'Review of Site Status',2,NULL,'Only noting security updates Below\r\nThis is a lot of updates. I have to run each one, test the site and continue. I will need to ask Billy durring the process to see what needs testing.\r\nAfter those are done we will end up with a staging site as well that is up to date and synced with the live site as we deploy so it is easier to test features.\r\n\r\n<b>Quote only considers all work going well. Does not consider a stop point where a bug from an update breaks an existing feature. At that point we need to talk to the client.</b>\r\n\r\nReview backup plan.\r\nMake sure they are working.\r\nInstall munin/monit\r\nMake sure APC is installed for better performance\r\n\r\n\r\n#####################\r\nUpdates Needed Report\r\nDrupal Core Update 6.2 to 6.28\r\n5 security updates for this module/core\r\n\r\nChoas Tools to 6.x-1.8\r\n3 security updates needed here.\r\n\r\nDate 6.x-2.7 \r\n2 Security updates here\r\n\r\nEmail Field 6.x-1.2\r\n2 Security updates needed\r\n\r\nNode Reference URL Widget\r\n2 Updates\r\n\r\nNodeWords\r\n2 Updates\r\n\r\nPanels\r\n1 Update\r\n\r\nViews\r\n4 updates\r\n\r\nWebform\r\n3 Updates\r\n\r\nFusion Theme\r\n1 Update',1360171064,NULL,NULL,2,NULL,NULL,NULL),(56,60,0,'See why drumonitor is now broke on cron',2,NULL,'PDOException: SQLSTATE[23000]: Integrity constraint violation: 1048 Column \'report_group_audience_created\' cannot be null: INSERT INTO {field_revision_report_group_audience} (entity_type, entity_id, revision_id, bundle, delta, language, report_group_audience_gid, report_group_audience_state, report_group_audience_created) VALUES (:db_insert_placeholder_0, :db_insert_placeholder_1, :db_insert_placeholder_2, :db_insert_placeholder_3, :db_insert_placeholder_4, :db_insert_placeholder_5, :db_insert_placeholder_6, :db_insert_placeholder_7, :db_insert_placeholder_8); Array ( [:db_insert_placeholder_0] => node [:db_insert_placeholder_1] => 177 [:db_insert_placeholder_2] => 177 [:db_insert_placeholder_3] => dm_report [:db_insert_placeholder_4] => 0 [:db_insert_placeholder_5] => und [:db_insert_placeholder_6] => 2 [:db_insert_placeholder_7] => [:db_insert_placeholder_8] => ) in field_sql_storage_field_storage_write() (line 449 of /Library/WebServer/htdocs/drumonitor/site/modules/field/modules/field_sql_storage/field_sql_storage.module).',1360171787,NULL,NULL,2,NULL,NULL,NULL),(57,61,0,'Review of Site Status',2,NULL,'Modules up to date\r\nUbuntu 5.3.2-1ubuntu4.9 php may need updating\r\nand apache\r\nApache/2.2.14 (Ubuntu)\r\n',1360172102,NULL,NULL,2,NULL,NULL,NULL),(58,62,0,'RMA Spam issues',2,NULL,'RMA - Newsletters and forms - major spam - 750 since yesterday. Can we add \"captcha\"?\r\n\r\n[PENDING INTERNAL REVIEW]\r\n\r\n[ ]This is a new feature and should be estimated and approved\r\n\r\n\r\n\r\nI did some testing to make sure the User+ Module I made would not get in the way.\r\n\r\nIn the past 2 days there has been about 30-50 new spam looking users.\r\n\r\nI checked all the web forms and there was only 20+ new submissions out of all the 7 forms. \r\n\r\nI can install a captcha. Looking at this ticket is see \"This is a new feature estimate and get approved\" so I would say 2 hours to install, test and deploy.\r\n\r\n.5 is for the long deploy process. Testing is to make sure what ever is used does not get in the way of the User+ module and the other time is to make sure it is setup as needed for the Webforms.\r\n',1360173396,NULL,NULL,5,NULL,NULL,NULL),(59,63,0,'Security Updates Review',2,NULL,'Drupal Core needs 2 updates\r\nChoas tools\r\nContext\r\nGlobal Redirect\r\nUbercart\r\nPrint\r\nWebforms\r\nFusion\r\n\r\nApache and PHP are not in our hands.\r\n\r\n\r\nI will outline as well some test procedures so all updates have to pass this list before they go live.\r\n',1360173563,NULL,NULL,2,NULL,NULL,NULL),(60,64,0,'Geo bug ',2,NULL,'Oak Square is not showing up in the proper place on our locations page. Is there a way for me to fix this? The address is correct on the site and the google link.\r\n\r\nB: Look at geolocation; give to Al\r\n\r\n[ ]Log in and go here: oaksquare/node/527/edit\r\n\r\n[ ]under the locations field set there is the geocode info\r\n\r\n[ ]It looks like its already being pulled in via google but at a postal code level\r\n',1360174047,NULL,NULL,1,NULL,NULL,NULL),(61,65,0,'Date Home page sorted Desc',2,NULL,'Al - Had to add a filter as well to limit events to = OR greater than today and then the sort DESC\r\n\r\nI only did this to the home page block_2\r\n\r\nThere is another one should I do it there as well?\r\n',1360175549,NULL,NULL,1,NULL,NULL,NULL),(62,66,0,'Large File work',2,NULL,'Our support department is looking for a mechanism that is incorporated into our website we customers and transfer files to us we they are having support issues. We would need it to be secure and be able to support up to a 5GB file transfer. Do you have any suggestions for us?\r\nBilly to estimate and further refinement and he\'ll send her questions.\r\nChloe to let her know we are on it.\r\n\r\n[ ]We should maybe look into YouSendIt or another service to see if this could be handled more appropriately through a 3rd party\r\n\r\nAl -\r\n1. Maybe we could build a module that hooks into S3 by amazon for cheap storage and retrieval https://www.jungledisk.com/ and /or http://aws.amazon.com/s3/\r\nhttp://aws.amazon.com/s3/#common-use-cases\r\nOr Rackspace\r\nhttp://www.rackspace.com/cloud/files/pricing/\r\nNo \"in\" costs just $10 a Gigabyte and $18 out\r\n\r\n2. Google Docs does have a Form feature and with the right Google App Plugin you could upload large files.\r\nhttp://www.google.com/enterprise/marketplace/search?query=form&categoryId=\r\n',1360176809,NULL,NULL,1,NULL,NULL,NULL),(63,67,0,'Menu item in wrong place see attached',2,NULL,'see attached\r\nIn Chrome',1360177376,NULL,NULL,1,NULL,NULL,NULL),(64,68,0,'Review of Site Status',2,NULL,'<p>Drupal Modules Backups? Go APC over Varnish in the process ? ################# Drupal is behind Drupal core 3 versions behind Chaos tools which runs most of the site! Date Email Field Location Node Words Organic Groups Spaces!!!! Revisioning Views Webform Fusion This site will take a TON of testing to make sure it is ready. In the process I would like to document key features to test and possibly auotmate the testing if it is worth it?</p>',1360180519,NULL,NULL,3,NULL,NULL,NULL),(65,69,0,'Should send me a notice since I am subscribed to ALL Tasks',2,NULL,'test',1360183982,NULL,NULL,1,NULL,NULL,NULL),(66,73,0,'Brand new task from email client',2,NULL,'<p></p><meta http-equiv=\"Content-Type\" content=\"text/html charset=us-ascii\" />Test Test w. attachment <img height=\"521\" width=\"800\" apple-width=\"yes\" apple-height=\"yes\" id=\"c434e8ac-d8f2-44b0-afbc-4dc43d840ca6\" src=\"cid:2F4451B7-99A8-4FD5-B98B-1709865465A3\" />',1360190404,NULL,NULL,1,NULL,NULL,NULL),(67,74,0,'WestSububan Y Needs apc and monit/munin setup',2,NULL,'we had to increase rackspace but this would be better.',1360253331,NULL,NULL,1,NULL,NULL,NULL),(68,77,0,'Use Case #1',2,NULL,'<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>\n',1360268958,NULL,NULL,1,NULL,NULL,NULL),(69,78,0,'Secure PM site ',2,NULL,'Anonymous can not see it.\r\nPeople only see nodes in their group unless staff.\r\nPeople are basically only in the /user area unless they are staff.\r\n',1360270444,NULL,NULL,1,NULL,NULL,NULL),(70,79,0,'westsuburbanymca.org does not ping at www',2,NULL,'ping westsuburbanymca.org = fail\r\nping www.westsuburbanymca.org = good',1360327169,NULL,NULL,2,NULL,NULL,NULL),(71,132,0,'FMK - Please check config for images.fibermark.com',2,NULL,'<p>Images.fibermark.com automatically adds in www. in front and comes up with<br />\r\nattached error.<br />\r\nThanks</p>\r\n<p>Kristen Fossum<br />\r\nFreshJones Creative<br />\r\n14 Miner Street<br />\r\nGreenfield, MA 01301</p>\r\n<p><a href=\"mailto:kristen@freshjones.com\">kristen@freshjones.com</a><br /><a href=\"http://www.freshjones.com\">www.freshjones.com</a><br />\r\n413.475.1803</p>\r\n',1360344421,NULL,NULL,1,NULL,NULL,NULL),(72,142,0,'Sending attachments again',2,NULL,'<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>\n<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?</p>\n',1360350451,NULL,NULL,1,NULL,NULL,NULL),(73,143,0,'Re: poker mpm 2013 site refresh',2,NULL,'<p>Got the link but don\'t see any questions yet. </p>\n<p>Also, make sure people feel safe about driving home. I don\'t want anyone to get hurt or stuck driving home in this weather. Thanks!</p>\n<p>Kind regards,<br />\nChloe</p>\n<p>Chloe Jones<br />\nFreshJones Creative<br />\n413.475.1810 (o)<br />\n413.522.6351 (m)<br /><a href=\"mailto:chloe@freshjones.com\">chloe@freshjones.com</a></p>\n',1360350601,NULL,NULL,1,NULL,NULL,NULL),(74,144,0,'Varnish issues',2,NULL,'<p>Issue from Katie from 4 days ago and 10 days ago.<br />\r\nBoth time Varnish failed</p>\r\n<p> ****</p>\r\n<p>** **</p>\r\n<p>*Katie Klepinski*</p>\r\n<p>*Marketing &amp; Internet Communications Manager*         *<br />\r\n*YMCA OF GREATER BOSTON****</p>\r\n<p>3 Center Plaza, Suite 901, Boston, MA 02108****</p>\r\n<p>617-927-8010****</p>\r\n<p><a href=\"mailto:kklepinski@ymcaboston.org\">kklepinski@ymcaboston.org</a>****</p>\r\n<p>Website <http:></http:> |<br />\r\nTwitter<http:>|<br />\r\nFacebook <http:> |<br />\r\nGoodSearch<http:><br />\r\n****</http:></http:></http:></p>\r\n<p>** **</p>\r\n<p>*The Y:  We\'re for youth development, healthy living and social<br />\r\nresponsibility.*</p>\r\n<p>** **</p>\r\n',1360528981,NULL,NULL,1,NULL,NULL,NULL),(75,145,0,'Use Case 1 with attachment',2,NULL,'<p>this is the use case, new email from client with attachment.</p>\n',1360529281,NULL,NULL,1,NULL,NULL,NULL),(76,146,0,'youtube video settings to work on http://www.bostonycamps.org/overnight-camp domain',2,NULL,'http://www.bostonycamps.org/overnight-camp\r\nJust needs to be set at youtube to allow that domain.\r\n\r\nI notified K for her login info',1360592501,NULL,NULL,1,NULL,NULL,NULL),(77,147,0,'Padding seen on Banner ',2,NULL,'see attached',1360593001,NULL,NULL,1,NULL,NULL,NULL),(78,148,0,'font failure ybosont',2,NULL,'Font server fails quite often',1360595812,NULL,NULL,1,NULL,NULL,NULL),(79,149,0,'Security Module',2,NULL,'http://drupal.org/project/seckit \r\n\r\nThis can be a good addition.',1360596913,NULL,NULL,2,NULL,NULL,NULL),(80,150,0,'Broken Links',2,NULL,'Can you test something on your end?  Search: specifier awards. \r\nSee second to last search result called “Specifier Awards”.  I tracked it back to a node 753 that looks like it falls under the node type “Design”.\r\nSo I looked up all node types called “Design” and tested the search of a few other examples and they all lead to broken links.\r\nI have to assume they were all created for a reason, so I don’t want to go unpublishing or deleting anything… but do you know why they are there and what the use is?\r\nIf they need to be published, how can we remove them from the search results so people aren’t getting bad links?\r\n \r\nThanks\r\nDanielle',1360675078,NULL,NULL,1,NULL,NULL,NULL),(81,151,0,'iPad cuts off on right step 3',2,NULL,'Asked client to verify since I can not replicate on ipad or emulator.\r\nsee attached.',1360675472,NULL,NULL,1,NULL,NULL,NULL),(82,152,0,'double check the font title on the billboards both on browser and iPad again.',2,NULL,'I will double check the font title on the billboards both on browser and iPad again.\r\n\r\n\r\nOn Feb 11, 2013, at 5:08 PM, Danielle Cutler <dcutler@fibermark.com> wrote:\r\n\r\n And #3 looks good except now I see it may have affected the billboards on the laptop?\r\nHad similar issues on my laptop, as well.\r\n',1360678078,NULL,NULL,1,NULL,NULL,NULL),(83,153,0,'Font size',2,NULL,'see attached',1360683981,NULL,NULL,1,NULL,NULL,NULL),(84,154,0,'Cron job not running the needed data import since 2/6',2,NULL,'Check the watchdog',1360684352,NULL,NULL,1,NULL,NULL,NULL),(85,155,0,'Market Applications filter shifts down',2,NULL,'see attached',1360688654,NULL,NULL,1,NULL,NULL,NULL),(86,156,0,'Staging setup for yboston had an issue',2,NULL,'see why the ftp settings did not work',1360695872,NULL,NULL,1,NULL,NULL,NULL),(87,157,0,'Check if menu is in scope to make unique.',2,NULL,'<p>See attached.<br />\nY Camps.</p>\n',1360700581,NULL,NULL,1,NULL,NULL,NULL),(88,159,0,'Updating YWeb API Calls',2,NULL,'<p>All sites that use the Yweb API client connections should get the same<br />\nupdate that we did for ccc_clients (West Suburban YMCA).</p>\n<p>Attached is the change necessary and should be applied to the following<br />\nsites:<br />\n1. YMCA Boston<br />\n2. YMCA Old Colony<br />\n3. YMCA St Louis</p>\n',1360761361,NULL,NULL,1,NULL,NULL,NULL),(89,160,0,'Look into a good documentation tool for both code and txt files',2,NULL,'<p>Decide on what would be a good documentation tool to use to parse all this.</p>\r\n\r\n\r\nhttp://www.naturaldocs.org/',1360762561,NULL,NULL,1,NULL,NULL,NULL),(90,161,0,'Prepare for Fibermark VD Tool',2,NULL,NULL,1360789360,NULL,NULL,1,NULL,NULL,NULL),(91,162,0,'Natural Doc Install',2,NULL,'Setup natural docs for this project http://www.naturaldocs.org/\r\nPlace it on the pm server \r\nsetup git to be pulled on updates\r\nand parse it.\r\nconnect it back to the Project or?',1360789475,NULL,NULL,1,NULL,NULL,NULL),(92,163,0,'Bullets on events see attached SPHHS',2,NULL,'<p>Hello Al:</p>\r\n<p>I noticed that bullet points are displaying incorrectly for event listings on the SPHHS site. I?ve attached a screenshot showing what it looks like currently. Can you take a look? Thank you.</p>\r\n<p>Regards,</p>\r\n<p>Matt</p>\r\n',1360789681,NULL,NULL,1,NULL,NULL,NULL),(93,164,0,'Bug during comment processing',2,NULL,'Notice: Undefined offset: 4 in sm_get_cid_via_read_more_comment() (line 840 of /var/www/mailhandler/projectmanager/live/sites/all/modules/custom/simplified_mailhandler/inc/simplified_mailhandler_helpers.inc).\r\n\r\nRe: Comment for Task: FMK\r\n\r\nSee email in Gmail',1360789919,NULL,NULL,1,NULL,NULL,NULL),(94,165,0,'Webform on FMK missing Canada option',2,NULL,'Danielle noted below and I think you did the setup on these so maybe you can cover this one? Just let me know if not.\r\n\r\nCan you take a look at this form… we addressed this some time ago, but I think this form slipped through the cracks.\r\nLike all other webforms, the country and state fields should allow for global submissions.\r\nFor now, I just have the customer using the print version of the awards entry form.\r\nThanks!\r\nDanielle\r\n \r\nHi Danielle,\r\n \r\nI had a call from April at Colortime in Vancouver and she is trying to submit an online specifier award application but said it only list US states and she can\'t put the Canadian provinces in.  She tried leaving it blank but it won\'t allow her to submit the form.  Do you know of a work-around for this issue?\r\n \r\nThanks Mike\r\n\r\n',1360790090,NULL,NULL,1,NULL,NULL,NULL),(95,166,0,'See why fiber mark cache not cleared on deployment',2,NULL,'<p>had to do it manually for fmk push</p>\n',1360797002,NULL,NULL,1,NULL,NULL,NULL),(96,167,0,'Make burn down chart',2,NULL,'<p>Set up burn down chart need it for these feature iteration</p>\n',1360798981,NULL,NULL,1,NULL,NULL,NULL),(97,168,0,'Width on fiber mark sometimes causes spotlights to be too compacted',3,NULL,'<p>and the text drops down.<br />\nsee attached.<br /><a href=\"http://www.fibermark.com/environment\">http://www.fibermark.com/environment</a></p>\n',1360805281,NULL,NULL,1,NULL,NULL,NULL),(98,169,0,'report of scrunched up filters on narrow layout',3,NULL,'see attached',1360848100,NULL,NULL,1,NULL,NULL,NULL),(99,170,0,'Push live and test ticket #169',3,NULL,NULL,1360850869,1367553600,NULL,2,NULL,NULL,NULL),(100,171,18,'Email to Kristen went into her spam not sure why test v1',3,NULL,'Test Update to Ticket 100 v2',1360818000,1367380800,2.50,2,1,3.00,1);
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-02 19:36:42
